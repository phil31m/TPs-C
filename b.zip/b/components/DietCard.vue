<template>
  <div style="border:1px ;padding:1rem; margin:1rem; width:250px;">
    <img :src="regime.image" :alt="regime.name" style="width:100%; height:120px; ">
    <h3>{{ regime.name }}</h3>
    <p>{{ regime.description }}</p>
    <div>
      <strong>Autorisés:</strong>
      <ul>
        <li v-for="item in regime.allowed" :key="item">{{ item }}</li>
      </ul>
      <strong v-if="regime.forbidden && regime.forbidden.length">Interdits:</strong>
      <ul v-if="regime.forbidden && regime.forbidden.length">
        <li v-for="item in regime.forbidden" :key="item">{{ item }}</li>
      </ul>
    </div>
    <NuxtLink :to="'/recipes?regime=' + regime.id" style="color:blue;">Voir les recettes compatibles</NuxtLink>
  </div>
</template>

<script>
export default {
  props: ['regime']
}
</script> 