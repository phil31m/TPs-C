<template>
  <div>
    <h1>Home Page</h1>
    <div style="display:flex; flex-wrap:wrap;">
      <RecipeCard v-for="recipe in featuredRecipes" :key="recipe.id" :recipe="recipe" />
    </div>
  </div>
</template>

<script setup>
import RecipeCard from '~/components/RecipeCard.vue'
const { data: db, pending, error } = useFetch('/fakedb.json')
const featuredRecipes = computed(() => db.value?.recipes?.slice(0, 6) || [])
</script>

<style scoped>
div {
  padding: 1rem;
}
h1, h2 {
  text-align: center;
}
</style>