<template>
  <div>
    <h1 class="re1">Régimes</h1>
    <div class="re2">
      <DietCard v-for="regime in regimes" :key="regime.id" :regime="regime" />
    </div>
  </div>
</template>

<script setup>
import DietCard from '~/components/DietCard.vue'
const { data: db, pending, error } = useFetch('/fakedb.json')
const regimes = computed(() => db.value?.regimes || [])
</script>

<style scoped>
.re1 {
  text-align: center;
  margin-bottom: 16px;
  color: #2c3e50;
  font-size: 32px;
}
.re2 {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  justify-content: center;
}
</style>