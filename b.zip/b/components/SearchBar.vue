<template>
  <div class="s1">
    <div class="s2">
      <input
        v-model="searchQuery"
        @input="handleSearch"
        type="text"
        :placeholder="placeholder"
        class="s3"
      />
      <button
        v-if="searchQuery"
        @click="clearSearch"
        class="s4"
      >

      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const props = defineProps({
  placeholder: {
    type: String,
    default: 'Rechercher une recette...'
  },
  modelValue: {
    type: String,
    default: ''
  }
})

const emit = defineEmits(['update:modelValue', 'search'])

const searchQuery = ref(props.modelValue)

const handleSearch = () => {
  emit('update:modelValue', searchQuery.value)
  emit('search', searchQuery.value)
}

const clearSearch = () => {
  searchQuery.value = ''
  emit('update:modelValue', '')
  emit('search', '')
}
</script>

<style scoped>
.s1 {
  width: 100%;
  max-width: 500px;
}

.s2 {
  position: relative;
  display: flex;
  align-items: center;
}

.s3 {
  width: 100%;
  padding: 12px 40px 12px 40px;
  border: 2px solid #e1e5e9;
  font-size: 16px;
  background: #fff;
  color: #333;
}

.s4 {
  position: absolute;
  right: 8px;
  background: none;
  border: none;
  color: #888;
  font-size: 18px;
  outline: none;
}
</style>