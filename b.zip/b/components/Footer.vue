<template>
  <footer class="f1">
    <div class="f2">
      <a href="" class="f3">Mentions légales</a>
      <a href="google.com" class="f3">Contact</a>
    </div>
  </footer>
</template>

<script setup>
</script>

<style scoped>
.f1 {
  background: #000;
  color: #fff;
  padding: 16px;
}
.f2 {
  margin-bottom: 8px;
}
.f3 {
  color: #fff;
  margin: 0 16px;
}
.f4 {
  margin: 0;
}
</style>