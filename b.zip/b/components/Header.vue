<template>
  <header class="h1">
    <nav class="h2">
      <NuxtLink to="/" class="h3">Accueil</NuxtLink>
      <NuxtLink to="/recipes" class="h3">Recettes</NuxtLink>
      <NuxtLink to="/regimes" class="h3">Régimes</NuxtLink>
    </nav>
  </header>
</template>

<script setup>
</script>

<style scoped>
.h1 {
  background: #000;
  color: #fff;
  padding: 16px;
}

.h2 {
  display: flex;
  gap: 16px;
}

.h3 {
  color: #fff;
  margin-right: 16px;
}
</style>