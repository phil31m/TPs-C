<template>
  <div v-if="recipe" class="r1">
    <img :src="recipe.image" :alt="recipe.title" class="r2">
    <h2 class="r3">{{ recipe.title }}</h2>
    <p class="r4">{{ recipe.description }}</p>
    <p class="r4">Temps: {{ recipe.time }} min</p>
    <p class="r4">Difficulté: {{ recipe.difficulty }}</p>
    <p class="r4">Catégorie: {{ recipe.category }}</p>
    <div class="r5">
      <strong>Régimes compatibles:</strong>
      <span v-for="regime in recipe.regimes" :key="regime" class="r6">{{ regime }}</span>
    </div>
    <div class="r7">
      <h3 class="r8">Ingrédients</h3>
      <ul class="r9">
        <li v-for="ingredient in recipe.ingredients" :key="ingredient">{{ ingredient }}</li>
      </ul>
      <h3 class="r8">Étapes</h3>
      <ol class="r10">
        <li v-for="(step, idx) in recipe.steps" :key="idx">{{ step }}</li>
      </ol>
    </div>
    <p class="r4">Auteur: {{ recipe.author }}</p>
  </div>
</template>

<script>
export default {
  props: ['recipe']
}
</script>

<style scoped>
.r1 {
  border: 1px solid #000;
  padding: 16px;
  margin: 16px;
}
.r2 {
  width: 100%;
  max-width: 400px;
  height: 200px;
}
.r3 {
  margin: 0 0 8px 0;
}
.r4 {
  margin: 0 0 8px 0;
}
.r5 {
  margin-bottom: 8px;
}
.r6 {
  font-size: 13px;
  border: 1px solid #000;
  margin-right: 4px;
  padding: 2px 6px;
}
.r7 {
  margin-top: 8px;
}
.r8 {
  font-size: 16px;
  margin-bottom: 8px;
}
.r9, .r10 {
  padding-left: 16px;
}
</style>