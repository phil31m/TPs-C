<template>
  <div>
    <RecipeDetailSection v-if="recipe" :recipe="recipe" />
    <div v-else-if="notFound" class="d1">Recette introuvable</div>
    <div v-else>Chargement...</div>
  </div>
</template>

<script setup>
import RecipeDetailSection from '~/components/RecipeDetailSection.vue'
import { useRoute } from 'vue-router'
import { computed } from 'vue'

const route = useRoute()
const id = computed(() => Number(route.params.id))
const { data: db, pending, error } = useFetch('/fakedb.json')
const recipe = computed(() => db.value?.recipes?.find(r => r.id === id.value) || null)
const notFound = computed(() => db.value && !recipe.value)
</script>

<style scoped>
.d1 {
  max-width: 700px;
  margin: 0 auto;
  padding: 16px;
  background: #fff;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.d2 {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
}
.d3 {
  width: 200px;
  height: 150px;
  border-radius: 4px;
}
.d4 {
  font-size: 20px;
  margin-bottom: 8px;
}
.d5 {
  font-size: 16px;
  margin-bottom: 8px;
}
.d6 {
  font-size: 14px;
  margin-bottom: 8px;
}
.d7 {
  background: #eee;
  color: #333;
  padding: 2px 6px;
  border-radius: 8px;
  font-size: 13px;
  margin-right: 4px;
}
</style>