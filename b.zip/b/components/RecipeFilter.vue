<template>
  <div style="border:1px solid #ccc; padding:1rem; margin-bottom:1rem;">
    <input v-model="search" @input="emitFilters" placeholder="Recherche..." style="margin-bottom:8px; width:100%;">
    <div>
      <label v-for="regime in availableRegimes" :key="regime.id" style="margin-right:8px;">
        <input type="checkbox" :value="regime.id" v-model="selectedRegimes" @change="emitFilters"> {{ regime.name }}
      </label>
    </div>
    <div>
      <label>Temps max (minutes):</label>
      <input type="number" v-model.number="maxTime" @input="emitFilters" min="0" style="width:60px;">
    </div>
    <button @click="emitFilters" style="margin-top:8px;">Filtrer</button>
  </div>
</template>

<script>
export default {
  props: ['availableRegimes'],
  data() {
    return {
      search: '',
      selectedRegimes: [],
      maxTime: 0
    }
  },
  methods: {
    emitFilters() {
      this.$emit('filter-change', {
        search: this.search,
        regimes: this.selectedRegimes,
        maxTime: this.maxTime
      })
    }
  }
}
</script>