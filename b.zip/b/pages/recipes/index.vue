<template>
  <div>
    <RecipeFilter :availableRegimes="regimes" @filter-change="applyFilters" />
    <div v-if="filteredRecipes.length === 0" class="rg2">
      Aucune recette trouvée ou erreur de chargement.
    </div>
    <div v-else style="display:flex; flex-wrap:wrap;">
      <RecipeCard v-for="recipe in filteredRecipes" :key="recipe.id" :recipe="recipe" />
    </div>
  </div>
</template>

<script setup>
import RecipeCard from '~/components/RecipeCard.vue'
import RecipeFilter from '~/components/RecipeFilter.vue'
import { useRoute } from 'vue-router'
const { data: db, pending, error } = useFetch('/fakedb.json')
const recipes = computed(() => db.value?.recipes || [])
const regimes = computed(() => db.value?.regimes || [])
const route = useRoute()
const filters = ref({ search: '', regimes: [], maxTime: 0 })
const filteredRecipes = computed(() => {
  let filtered = recipes.value
  if (filters.value.search) {
    filtered = filtered.filter(r =>
      r.title.toLowerCase().includes(filters.value.search.toLowerCase()) ||
      r.description.toLowerCase().includes(filters.value.search.toLowerCase())
    )
  }
  if (filters.value.regimes.length) {
    filtered = filtered.filter(r =>
      filters.value.regimes.every(reg => r.regimes.includes(reg))
    )
  }
  if (filters.value.maxTime) {
    filtered = filtered.filter(r => r.time <= filters.value.maxTime)
  }
  return filtered
})

onMounted(() => {
  if (route.query.regime) {
    filters.value.regimes = [route.query.regime]
  } else {
    filters.value.regimes = []
  }
})



function applyFilters(newFilters) {
  filters.value = newFilters
}
</script>

<style scoped>
.rg1 {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}
.rg2 {
  text-align: center;
  padding: 16px;
  color: #666;
  font-size: 16px;
}
</style>