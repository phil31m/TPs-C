<template>
  <div style="border:1px solid #ccc; padding:1rem; margin:1rem; width:250px;">
    <img :src="recipe.image" :alt="recipe.title" style="width:100%; height:120px; object-fit:cover;">
    <h3>{{ recipe.title }}</h3>
    <p>{{ recipe.description }}</p>
    <p>Temps: {{ recipe.time }} min</p>
    <div>
      <span v-for="regime in recipe.regimes" :key="regime" style="font-size:0.8em; border:1px solid #eee; margin-right:4px; padding:2px 6px;">{{ regime }}</span>
    </div>
    <NuxtLink :to="'/recipes/' + recipe.id" style="color: #007bff; text-decoration: underline; cursor: pointer; font-weight: 500;">Voir la recette</NuxtLink>
  </div>
</template>

<script>
export default {
  props: ['recipe']
}
</script> 